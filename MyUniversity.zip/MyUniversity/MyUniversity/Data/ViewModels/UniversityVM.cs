﻿namespace MyUniversity.Data.ViewModels
{
    public class UniversityVM
    {
        public int Rate { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Location { get; set; }
        public DateTime DateCreated { get; set; }
        public string Address { get; set; }
    }
}
